#jsHybugger Plugin for Cordova 3.x

Visit http://www.jshybugger.com/ for more information.
